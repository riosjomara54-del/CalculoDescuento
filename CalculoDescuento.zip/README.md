# Proyecto: Cálculo de Descuento en Compras (Java)

## Descripción
Este programa en Java calcula el descuento aplicado a una compra utilizando métodos con parámetros, retorno de valores y sobrecarga.  
Se incluyen dos versiones del método `calcularDescuento`:
1. Una que recibe el monto total y el porcentaje de descuento.
2. Otra sobrecargada que aplica por defecto un **10% de descuento**.

## Ejecución
1. Compilar el archivo:
   ```bash
   javac CalculoDescuento.java
   ```

2. Ejecutar el programa:
   ```bash
   java CalculoDescuento
   ```

## Ejemplo de Salida
```
=== Cálculo con descuento del 10% por defecto ===
Monto original: $200.0
Descuento aplicado: $20.0
Monto final a pagar: $180.0

=== Cálculo con descuento del 15.0% ===
Monto original: $350.0
Descuento aplicado: $52.5
Monto final a pagar: $297.5
```

## GitHub
El código debe subirse al repositorio asignado en GitHub con **commit y push**.  
En Moodle se entrega el enlace directo al repositorio.
